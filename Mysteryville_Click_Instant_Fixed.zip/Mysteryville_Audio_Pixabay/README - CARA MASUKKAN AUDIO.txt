MYSTERYVILLE 3D — AUDIO PIXABAY

1. Download tujuh MP3 dari https://pixabay.com/sound-effects/
2. Rename MP3 tepat seperti berikut, dan letak di folder sounds/ (sebelah fail HTML):
   background.mp3  - muzik latar lembut
   city.mp3        - bunyi suasana bandar
   footsteps.mp3   - bunyi satu langkah kaki (pendek, bukan rakaman panjang)
   click.mp3       - klik butang
   correct.mp3     - jawapan betul
   wrong.mp3       - jawapan salah
   success.mp3     - misi/tahap selesai
3. Buka HTML melalui local server, contohnya VS Code Live Server.
4. Tekan mula permainan / sentuh skrin untuk membenarkan audio.
5. Butang 🔊 di bahagian atas = semua suara ON/OFF. Tetapan ⚙️ menyediakan slider muzik dan SFX berasingan.
6. Bunyi sintesis asal menjadi sandaran jika MP3 yang diperlukan tidak dijumpai. City ambience tidak ada sandaran kerana memang belum wujud dalam fail asal.

NOTA: Folder sound kosong kerana tiada fail MP3 Pixabay dilampirkan. Sila download sendiri dan patuhi lesen setiap audio.

Jika memasukkan kod ini ke projek Vite/React, letakkan MP3 dalam public/sounds/ dan laraskan prefix alamat kepada /sounds/ jika perlu. HTML ini sendiri adalah fail standalone, bukan projek React.

Jangan pindahkan HTML tanpa folder sounds kerana audio MP3 bergantung pada laluan relatif tersebut.

KEMAS KINI FOOTSTEPS:
Bunyi footsteps.mp3 hanya dimainkan semasa watak bergerak dan berhenti serta-merta apabila input dilepaskan, termasuk ketika dialog/menu dibuka.
